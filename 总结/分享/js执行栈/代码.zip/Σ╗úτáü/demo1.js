
console.log('a');
setTimeout(() => {
    console.log('b');
})
console.log('c');


