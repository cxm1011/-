
console.log('a');
setTimeout(() => { 
    console.log('b');
},0);

new Promise((resolve, reject) => {
  console.log('c');
  for (var i = 0; i < 10000; i++) {
    i == 9999 && resolve();
  }
  console.log('d');
}).then(() => {
  console.log('e');
});
console.log('f');

